#include "ofApp.h"

//--------------------------------------------------------------
int main(){
	ofSetupOpenGL(1280, 720, OF_WINDOW);
	ofRunApp(new ofApp()); // start the app
}
